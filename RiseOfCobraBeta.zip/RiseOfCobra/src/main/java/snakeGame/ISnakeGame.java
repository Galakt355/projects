package snakeGame;

public interface ISnakeGame {
    public int getNumberRedFrog();
    public void setNumberRedFrog(int numberRedFrog);

    public int getNumberGreenFrog();
    public void setNumberGreenFrog(int numberGreenFrog);

    public int getNumberBlueFrog();
    public void setNumberBlueFrog(int numberBlueFrog);

    public int getTimeSnakeSLEEP();
    public void setTimeSnakeSLEEP(int snakeSLEEP);

    public int getLengthSnake();
    public void setLengthSnake(int lengthSnake);
}
